# bioSite
A web project for building a personal bio site using HTML and CSS.


<html lang="en">
<head>
  <meta charset="UTF-8">

</head>
<body>

  <h1>CSD 340 Web Development with HTML and CSS</h1>
  
  <h2>Contributors</h2>
  <ul>
    <li> Instructo: Vianelis Martinez </li>
    <li>Student: Kusal Bhattarai</li>
  </ul>

</body>
</html>










